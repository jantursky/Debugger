package com.jantursky.debugger.interfaces;

public interface GlobalViewListener {

    void onGlobalLayout(int width, int height);

}
