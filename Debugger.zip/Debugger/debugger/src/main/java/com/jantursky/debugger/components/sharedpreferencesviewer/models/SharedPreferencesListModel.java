package com.jantursky.debugger.components.sharedpreferencesviewer.models;

import java.io.File;

public class SharedPreferencesListModel {

    public File file;

    public SharedPreferencesListModel(File file) {
        this.file = file;
    }
}
