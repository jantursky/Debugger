package com.jantursky.debugger.interfaces;

public interface ComponentListener {

    void closeComponent();

}
