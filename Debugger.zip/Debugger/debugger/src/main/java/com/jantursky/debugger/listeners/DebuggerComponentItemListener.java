package com.jantursky.debugger.listeners;

import com.jantursky.debugger.components.DebuggerComponent;

public interface DebuggerComponentItemListener {

    void onItemSelect(DebuggerComponent debuggerComponent);

}
