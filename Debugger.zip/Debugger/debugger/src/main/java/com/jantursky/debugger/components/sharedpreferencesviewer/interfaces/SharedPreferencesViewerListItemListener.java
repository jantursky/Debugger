package com.jantursky.debugger.components.sharedpreferencesviewer.interfaces;

import java.io.File;

public interface SharedPreferencesViewerListItemListener {

    void onFileClick(File file);

}
