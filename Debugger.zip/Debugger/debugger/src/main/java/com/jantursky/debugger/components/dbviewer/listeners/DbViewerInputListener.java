package com.jantursky.debugger.components.dbviewer.listeners;

public interface DbViewerInputListener {

    void applyInput(String text);

    void neutral();

}
